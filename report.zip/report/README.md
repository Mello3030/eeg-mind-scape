# Phase II Project Report — LaTeX source

Scope: the **web platform** (frontend + application server). The Phase I model
work — architecture, features, training, ablation — is deliberately out of scope
and is referenced only as an inference service with a fixed contract.

## Building

No LaTeX toolchain was available on the machine where this was written, so it
has **not been compiled**. Build it on Overleaf (upload the `report/` folder) or
locally with a full TeX Live / MiKTeX installation:

```bash
cd report
pdflatex main
pdflatex main      # second pass resolves \ref, \cite, ToC
```

Two passes are required. `main.tex` is the entry point; every chapter lives in
`sections/`.

Packages used beyond a base install: `tikz` (all diagrams), `pgfgantt` (the
timeline), `booktabs`, `tabularx`, `enumitem`, `titlesec`, `fancyhdr`,
`hyperref`. All are in TeX Live full and on Overleaf.

## Before submitting — three things to fill in

**1. Identity block.** Top of `main.tex`, every line marked `% EDIT`:
student names and roll numbers, guide name, department, college, academic
year, submission month. `\StudentC` is a placeholder — delete the row from the
title-page table if the team is two people.

**2. Screenshots.** `figures/` is empty. The document compiles without them and
prints a labelled placeholder box in each slot. Twelve slots are defined in
`sections/implementation.tex`, one per module:

| File | View to capture |
| --- | --- |
| `01-login.png` | Sign-in screen |
| `02-dashboard.png` | Dashboard with KPIs and gate weights |
| `03-patients.png` | Cohort registry |
| `04-patient-detail.png` | Patient record with probability trajectory |
| `05-upload.png` | New Analysis, drag-and-drop |
| `06-predictions.png` | Prediction history list |
| `07-result-gates.png` | Result detail — probabilities and gate breakdown |
| `08-result-biomarkers.png` | Result detail — decoded biomarkers |
| `09-eeg-viewer.png` | EEG viewer with scored crops marked |
| `10-performance.png` | Confusion matrix and per-class metrics |
| `11-settings.png` | Checkpoint inventory and switching |
| `12-report-pdf.png` | Generated PDF report |

To capture them, start both processes (`python backend/run.py --reload` in
`ML/`, `npm run dev` in the repo root) and sign in with the seeded demo
account. Note the dev server falls back to port 8081 when 8080 is taken.

**3. Verify the references.** All 48 entries are real published works,
standards or official documentation, but volume, issue, page and article
numbers were written from memory and could not be checked online from this
machine. Run them past your library or Google Scholar before submission.

## Dates

The timeline in `sections/timeline.tex` was inferred from git history and file
timestamps (Phase I outputs dated Apr–May 2026; integration work Aug 2026).
Correct the months and the semester labels to match your actual schedule.

## Numbers in the report

Everything quantitative was measured from this repository rather than
transcribed:

- Line counts, endpoint counts, route inventory — counted from the source tree.
- Latency table — read out of the `timing_ms` column of the workspace database.
- Confusion matrix, per-class metrics, gate activations — recomputed
  independently from the checkpoint and the cached test split while writing
  Chapter 6, and they match what the platform serves.
- Workspace state (3 users, 14 patients, 4 uploads, 13 predictions) — queried
  from `ML/backend/storage/qsfe.db`.

Section 6.5.6 logs three defects found during that verification pass. They are
reported rather than silently fixed; corrective actions are scheduled as T-15
to T-17 in Chapter 8.
